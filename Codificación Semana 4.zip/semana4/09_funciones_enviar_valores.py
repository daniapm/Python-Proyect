# Envio de valores

def suma(a, b): # valores que se reciben
    operacion = a + b
    return operacion

resultado = suma(2,7)
print(resultado)