# Desarrollar una función que solicite la carga del dia, mes y año y almacene dichos 
# datos en una tupla que luego debe retornar. 
# La segunda función a implementar debe recibir una tupla con la fecha y mostrarla por pantalla.

def cargarFecha():
    dia = int(input("Ingrese el número del dia: "))
    mes = int(input("Ingrese el número del mes: "))
    anno = int(input("Ingrese el número del año: "))
    return dia,mes,anno

def imprimirFecha(tuplaFecha):
    print(tuplaFecha[0],tuplaFecha[1],tuplaFecha[2], sep="/")


fecha = cargarFecha()
imprimirFecha(fecha)