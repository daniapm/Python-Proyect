# Definir una tupla con tres valores enteros. Convertir el contenido de la tupla a tipo lista. 
# Modificar la lista y luego convertir la lista en tupla.

fechaTupla1 = (25,12,2020)
print("Impresion tupla 1")
print(fechaTupla1)

fechaLista = list(fechaTupla1)
print("Imprimimos la lista que se copio de la tupla anterior")
print(fechaLista)

fechaLista[0]=31
print("Imprimimos la lista ya modificada")
print(fechaLista)

fechaTupla2 = tuple(fechaLista)
print("Imprimimos la segunda tupla que se copio de la lista")
print(fechaTupla2)