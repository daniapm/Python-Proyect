# Crea una tupla con números e indica el numero con mayor valor y el que menor tenga.

tuplaNumeros = (5,4,3,-2,1,6,455,3,6,6,6,6,6)

maximo = tuplaNumeros[0]
minimo = tuplaNumeros[0]
for i in tuplaNumeros:
    if i > maximo:
        maximo = i
    
    if i < minimo:
        minimo = i

print(f"El maximo es {maximo}")
print(f"El minimo es {minimo}")

# forma 2
print()
print("---------------------------------------------------------")
tuplaNumeros = (5,4,3,-2,1,6,455,3,6,6,6,6,6)
print(f"El maximo es {max(tuplaNumeros)}")
print(f"El minimo es {min(tuplaNumeros)}")