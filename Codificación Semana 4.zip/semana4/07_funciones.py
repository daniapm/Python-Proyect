# Definición y llamada

# Definición
def saludar():
    print("Hola este print se llama desde la función saludar")

def dibujarTablaDel5():
    for i in range(1,11):
        print("5 *", i , "=", i*5)

# llamado de funcion
saludar()
# llamado de funcion
dibujarTablaDel5()

# Ambito de variables
def test():
    n = 10
    
test()
#print(n)

m = 10
def test():
    print(m)

test()

def test():
    print(l)

l = 20
test()

def test():
    o = 5 # variable que solo existe dentro función
    print(o)

o = 15
test()

# instruccion de tipo global
def test():
    global o
    o = 5
    print(o)

o = 10
test()
print(o)