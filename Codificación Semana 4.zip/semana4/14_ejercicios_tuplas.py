# Crea una tupla con números, pide un numero por teclado e indica cuantas veces se repite.

tuplaNumeros = (5,4,3,2,1,6,45,3,6,6,6,6,6)
numero = int(input("Ingresa un número: "))

contador = 0
for i in tuplaNumeros:
    if numero == i:
        contador+=1
print(f"Hay {contador} repeticiones del {numero}")

print()
print("-------------------------------------------------------------------")

# forma 2

tuplaNumeros = (5,4,3,2,1,6,45,3,6,6,6,6,6)
numero = int(input("Ingresa un número: "))

print(f"Hay {tuplaNumeros.count(numero)} repeticiones del {numero}")
