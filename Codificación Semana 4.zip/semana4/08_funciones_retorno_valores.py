# Retorno de valores
def test():
    return "Una cadena retornada"

test()
print(test())

c = test() + " Otra cadena"
print(c)

def ejemplo():
    return [1,2,3,4,5]

print(ejemplo())
print(ejemplo()[-1])
print(ejemplo()[1:4])

lista = ejemplo()
print(lista)

# Retorno multiples
def ejemplo2():
    return "Una cadena", 20, [1,2,3]

# retorno tupla
print(ejemplo2())

cadena, numero, lista = ejemplo2()
print(cadena)
print(numero)
print(lista)