# definimos la lista principal
lista=[["juan","ana"], ["luis"], ["pedro","carlos","maria"]]

print(lista[len(lista)-1])
print("*************************************")
print(lista[-1])