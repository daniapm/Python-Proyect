# METODOS DICCIONARIOS
colores = { "amarillo":"yellow", "azul":"blue", "verde":"green" }

# get() Busca un elemento a partir de su clave y si no lo encuentra devuelve un valor por defecto
print(colores.get('negro', 'no se encuentra'))
print(colores.get('amarillo', 'no se encuentra'))

print("---------------------------------------------------------------------")

# keys() Genera una lista en clave de los registros del diccionario
print(colores.keys())

print("---------------------------------------------------------------------")

# values() Genera una lista en valor de los registros del diccionario
print(colores.values())
print("---------------------------------------------------------------------")

# items() Genera una lista en clave-valor de los registros del diccionario
print(colores.items())

for clave, valor in colores.items():
    print(clave, valor)

print("---------------------------------------------------------------------")
# pop() Extrae un registro de un diccionario a partir de su clave y lo borra, acepta valor por defecto
print(colores.pop('amarillo', 'no se ha encontrado'))
print(colores)

print("---------------------------------------------------------------------")
# clear() Borra todos los registros de un diccionario
colores.clear()
print(colores)