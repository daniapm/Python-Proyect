# definimos la lista principal
lista = [[1,1,1,1,1],[2,2,2,2,2]]
# sumamos los elementos de la primera sublista
suma1 = lista[0][0]+lista[0][1]+lista[0][2]+lista[0][3]+lista[0][4]
print(suma1)
print("**************************************************************")
suma2 = lista[1][0]+lista[1][1]+lista[1][2]+lista[1][3]+lista[1][4]
print(suma2)
print("**************************************************************")

suma1 = 0
for i in range(len(lista[0])):
    suma1 = suma1 + lista[0][i]

print(f"resultado de la suma con ciclo for sublista 1 es: {suma1}")
print("**************************************************************")

suma2 = 0
for x in range(len(lista[1])):
    suma2 = suma2 + lista[1][x]

print(f"resultado de la suma con ciclo for sublista 2 es: {suma2}")
print("**************************************************************")

granTotal = 0
for k in range(len(lista)):
    sumaTotal = 0
    for x in range(len(lista[k])):
        sumaTotal = sumaTotal + lista[k][x]
    print("**************************************************************")
    print(f"el resultado de todos los elementos de la lista[{k}] es: {sumaTotal}")
    granTotal = granTotal + sumaTotal
print("**************************************************************")
print(f"el resultado de todos los elementos de la lista principal es: {granTotal}")