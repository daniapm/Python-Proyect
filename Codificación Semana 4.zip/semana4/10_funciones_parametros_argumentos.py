# Argumentos y parametros

# Argumentos por posicion
def resta(a,b):
    operacion = a - b
    return operacion

resultado = resta(30,10)
print(resultado)

# Argumentos por nombre
resultado = resta(b=10,a=30)
print(resultado)

# Parametros por defecto
def resta(a=0, b=0):
    operacion = a - b
    return operacion

def resta(a=None, b=None):
    if a == None or b == None:
        print("Error: debes pasar dos números a la función")
        return
    return a-b

resultado = resta(a=20,b=10)
print(resultado)