# definir la lista principal
lista = [[1],[1,2],[1,2,3],[1,2,3,4],[1,2,3,4,5]]

suma = 0
for k in range(len(lista)):
    for i in range(len(lista[k])):
        suma = suma + lista[k][i]

print(f"La suma total de la lista principal es: {suma}")