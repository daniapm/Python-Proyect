# definicion de la lista principal
lista=[[100,7,85,8], [4,8,56,25], [67,89,23,1], [78,56]]

print(lista)

for k in range (len(lista[0])):
    if lista[0][k] > 50:
        lista[0][k] = 0
print("-------------------------------------------")
print(lista)
