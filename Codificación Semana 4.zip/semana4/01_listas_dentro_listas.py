# crear una lista 
lista = [[1,2,3],[4,5,6],[7,8,9],[10,11,12]]
#imprimir la lista completa
print(lista)
print("*************************************************************")
# para acceder a los elementos de la lista utilizamos los indices
# acceder a la primera sublista
print(lista[0])
print(lista[1])
print("*************************************************************")
# acceder a la primera sublista, y acceder al primer elemento de esta
print(lista[0][0])
print(lista[0][2])
# imprimir la lista con un ciclo for / la primera sublista
#print(len(lista[0]))
print("*************************************************************")
for i in range(len(lista[0])):
    print(lista[0][i])
print("*************************************************************")
for i in range(len(lista[1])):
    print(lista[1][i])
# imprimir cada uno de los elementos de cada lista contenida en la lista principal
print("*************************************************************")
for k in range(len(lista)):
    for i in range(len(lista[k])):
        print(lista[k][i])
