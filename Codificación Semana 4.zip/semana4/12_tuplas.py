# Tuplas

# Definición tupla
tupla = (100, "Hola", [1,2,3], -50)

print(tupla)
print("---------------------------------")

# acceso a los elementos con los indices
print(tupla[0]) # primer elemento de la tupla
print("---------------------------------")
print(tupla[-1]) # ultimo elemento de la tupla
print("---------------------------------")
print(tupla[2][-1])

# Slicing 
print("---------------------------------")
print(tupla[2:])
print("---------------------------------")
print(tupla[:])

#tupla[0] = 50 no se pueden modificar valores
#tupla.append(10) no se pueden agregar elementos a la tupla

# metodos de las tuplas

# len() saber la cantidad de elementos que tiene la tupla
print("---------------------------------")
print(len(tupla))

# index() saber la posicion de un elemento en la tupla
print("---------------------------------")
print(tupla.index(100))

# count() saber cuantas veces esta un elemento en la tupla
print("---------------------------------")
print(tupla.count(100))

# sum() suma los elementos de una tupla
tupla2 = (10,20,30,40,50)
print("---------------------------------")
print(sum(tupla2))

# max() obtiene el elemento mayor de la tupla
print("---------------------------------")
print(max(tupla2))

# min() obtiene el elemento menor de la tupla
print("---------------------------------")
print(min(tupla2))

# sorted() ordena automaticamente los ementos de la tupla de menor a mayor
print("---------------------------------")
print(sorted(tupla2))