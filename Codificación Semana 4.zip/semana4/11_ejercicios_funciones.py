# Crea un programa que pida dos número enteros al usuario y diga si alguno de ellos 
# es múltiplo del otro. Crea una función EsMultiplo que reciba los dos números, 
# y devuelve si el primero es múltiplo del segundo.

def esMultiplo(numero1, numero2):
    if numero1 % numero2 == 0:
        return True
    else:
        return False

num1 = int(input("Ingrese el número 1: "))
num2 = int(input("Ingrese el número 2: "))

if esMultiplo(num1,num2):
    print(num1, "es múltiplo de ", num2)
else:
    print(num1, "no es múltiplo de ", num2)

